import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminAccess } from '@/lib/security/auth';
import { getCustomers, createCustomer } from '@/lib/db/repositories/customer';
import { logger } from '@/lib/logger';

export async function GET(req: NextRequest) {
  const isAuthorized = await verifyAdminAccess(req);
  if (!isAuthorized) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get('q') || undefined;

    const customers = await getCustomers(search);
    return NextResponse.json({ customers });
  } catch (err) {
    logger.error('Error fetching customers list', err);
    return NextResponse.json({ error: 'Failed to retrieve customers' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const isAuthorized = await verifyAdminAccess(req);
  if (!isAuthorized) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, notes } = body;

    if (!name || name.trim() === '') {
      return NextResponse.json({ error: 'Customer name is required' }, { status: 400 });
    }

    const { customer, code } = await createCustomer(name.trim(), notes);
    logger.info('New customer created via Admin Dashboard', { customerId: customer.id, name });

    return NextResponse.json({
      success: true,
      customer,
      activationCode: code,
    });
  } catch (err) {
    logger.error('Error creating customer', err);
    return NextResponse.json({ error: 'Failed to create customer' }, { status: 500 });
  }
}
